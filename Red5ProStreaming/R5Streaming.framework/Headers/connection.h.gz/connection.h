//
//  connection.h
//  red5streaming
//
//  Created by Andy Zupko on 10/27/14.
//  Copyright (c) 2014 Andy Zupko. All rights reserved.
//

#ifndef red5streaming_connection_h
#define red5streaming_connection_h

#ifdef __cplusplus
extern "C" {
#endif
    
    
#ifdef __cplusplus
}
#endif

#endif
